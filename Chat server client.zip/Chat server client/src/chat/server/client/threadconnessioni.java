/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.server.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.io.DataInputStream;

/**
 *
 * @author miste
 */
public class threadconnessioni implements Runnable{
    private Server gestorechat;
    private Socket client = null;
    private BufferedReader input = null;
    private PrintWriter output = null;
    Thread chat;
    
    public threadconnessioni (Server gestorechat, Socket client){
        this.gestorechat = gestorechat;
        this.client = client;
        try{
            this.input = new BufferedReader(new InputStreamReader(client.getInputStream()));
            this.output = new PrintWriter(this.client.getOutputStream(),true);
        }catch(Exception e){
            System.out.println("Errore nella lettura");
        }
        chat = new Thread(this);
        chat.start();
    }
    
    public void run(){
        while(true){
            try{
                String m = null;
                while((m = input.readLine() == null)){
                }
                gestorechat.spedisciMessaggio(m);
            }catch(Exception e){
                System.out.println("Errore nella spedizione del messaggio");
            }
        }
    }
    
    public void spedisciMessaggiochat(String Messaggio){
        String messaggio = null;
        output.println(messaggio);
    }
}

