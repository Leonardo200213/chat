/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.server.client;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

/**
 *
 * @author miste
 */
public class Server implements Runnable {
    private int nconnessioni = 2;
    private List lista;
    private threadconnessioni[]listaconnessioni;
    Thread chat;
    private ServerSocket serverChat;
    
    public void gestionechat(int nconnessioni, List lista){
        this.lista = lista;
        this.listaconnessioni = new threadconnessioni[this.nconnessioni];
        chat = new Thread(this);
        chat.start();
    }
    
    @Override
    public void run(){
        boolean continua = true;
        try{
            serverChat = new ServerSocket(2567);
        }catch(IOException e){
            System.out.println("Errore nell'istanziamento del server");
            continua = false;
        }
        
        if(continua){
            try{
                for(int i=0; i<nconnessioni; i++){
                    Socket tempo = null;
                    tempo = serverChat.accept();
                    listaconnessioni[i] = new threadconnessioni(this, tempo);
                }
                serverChat.close();
            }catch(Exception e){
                System.out.println("Errore nell'istanziamento del server");
            }
        }
    }
    
    public void spedisciMessaggio(String m){
        lista.add(m);
        lista.select(lista.getItemCount()-1);
        for (int i=0; i<this.nconnessioni; i++){
            if(listaconnessioni[i] != null){
                listaconnessioni[i].spedisciMessaggiochat(m);
            }
        }
    }
}
