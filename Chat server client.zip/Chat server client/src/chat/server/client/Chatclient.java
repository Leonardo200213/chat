/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat.server.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

/**
 *
 * @author miste
 */
public class Chatclient implements Runnable{
    private Server gestorechat;
    private List lista;
    Thread chat;
    private Socket client;
    private BufferedReader input = null;
    private PrintWriter output = null;
    
    public void threadconnessioni(List lista, String ipServer, int porta){
        this.lista = lista;
        try{
            client = new Socket(ipServer, porta);
            this.input = new BufferedReader (new InputStreamReader(client.getInputStream()));
            this.output = new PrintWriter(client.getOutputStream(), true);
        }catch(Exception e){
            System.out.println("Impossibile connettersi al server");
        }
        chat = new Thread(this);
        chat.start();
    }
    
    public void run(){
        while(true){
            try{
                String m = null;
                while((m = input.readLine() == null)){
                }
                gestorechat.spedisciMessaggio(m);
            }catch(Exception e){
                System.out.println("Errore nell'invio del messaggio");
            }   
        }
    }
    
    public void spedisciMessaggiochat(String messaggio){
        try{
        output.println(messaggio);
        }catch(Exception e){
            
        }
    }
}
